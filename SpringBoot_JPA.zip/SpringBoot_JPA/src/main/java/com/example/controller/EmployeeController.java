package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.beans.Employee;
import com.example.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	
	@RequestMapping("/")
	public List<Employee> getAllEmployees() {
		return service.selectAll();
	}
	/*@RequestMapping(value="/employee/{min}-{max}",method=RequestMethod.GET)
	public List<Employee> getEmployeesWithSalaryBetween(@PathVariable double min, @PathVariable double max) {
		return service.selectSalaryBetween(min, max);
	}*/
	@RequestMapping(value="/employee/{designation}",method=RequestMethod.GET)
	public List<Employee> getEmployeesWithDesignation(@PathVariable("designation") String designation){
		return service.selectByDesignation(designation);
	}
	@RequestMapping(value="/employee/{id}",method=RequestMethod.GET)
	public Employee getEmployee(@PathVariable("id") int id) {
		return service.selectEmployee(id);
	}
	@RequestMapping(value="/",method=RequestMethod.POST)
	public void addEmployee(@RequestBody Employee employee) {
		service.insertEmployee(employee);
	}
	@RequestMapping(value="/",method=RequestMethod.PUT)
	public void updateEmployee(@RequestBody Employee employee) {
		service.updateEmployee(employee);
	}
	@RequestMapping(value="/employee/{id}",method=RequestMethod.DELETE)
	public void deleteEmployee(@PathVariable("id") int id) {
		service.deleteEmployee(service.selectEmployee(id));
	}
	
}
