package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.beans.Employee;

public interface Repository extends CrudRepository<Employee,String>{
	/*@Query("SELECT e.id,e.name FROM Employee e WHERE e.salary > min AND e.salary < max")
	List<Employee> findSalaryBetween(@Param("min") double min, @Param("max") double max);*/
	
	@Query(value="SELECT e.id,e.name FROM Employee e WHERE e.designation = :designation", nativeQuery=true)
	List<Employee> findByDesignation(@Param("designation") String designation);
	

}
