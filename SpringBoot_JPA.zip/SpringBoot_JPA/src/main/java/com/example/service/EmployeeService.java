package com.example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.beans.Employee;
import com.example.repository.Repository;

@Service
public class EmployeeService {
	@Autowired
	private Repository repository;

	public void insertEmployee(Employee employee) {
		repository.save(employee);
		System.out.println(employee + " inserted");
	}
	
	public void updateEmployee(Employee employee) {
		Employee query = repository.findById(employee.getId() + "").get();
		query.setName(employee.getName());
		query.setDesignation(employee.getDesignation());
		query.setSalary(employee.getSalary());
		repository.save(query);
		System.out.println(employee + " updated to " + query);
	}
	
	public void deleteEmployee(Employee employee) {
		repository.delete(employee);
		System.out.println(employee + " deleted");
	}
	
	public List<Employee> selectAll() {
		List<Employee> list = new ArrayList<Employee>();
		repository.findAll().forEach(list::add);
		return list;
	}
	
	public Employee selectEmployee(int id) {
		return repository.findById(id + "").get();
	}
	
	public List<Employee> selectByDesignation(String designation) {
		return repository.findByDesignation(designation);
	}
	
	/*public List<Employee> selectSalaryBetween(double min, double max) {
		return repository.findSalaryBetween(min, max);
	}*/
}
